import threading
import time
import socket

import RNS
from RNS.Interfaces.Interface import Interface


class WebsocketClientInterface(Interface):

    DEFAULT_IFAC_SIZE = 16
    RECONNECT_DELAY_SECONDS = 5

    def __str__(self):
        return f"UdpClientInterface[{self.name}/{self.target_host}:{self.target_port}]"

    def __init__(self, owner, configuration, server_socket=None, remote_address=None):
        super().__init__()
        self.owner = owner
        self.parent_interface = None
        self.server_socket = server_socket  # For server-side usage
        self.remote_address = remote_address  # For server-side usage
        self.udp_socket = None  # For client-side usage

        ifconf = Interface.get_config_obj(configuration)
        self.name = ifconf.get("name")
        self.target_host = ifconf.get("target_host")
        self.target_port = int(ifconf.get("target_port"))

        if not self.server_socket:  # Client-side mode
            thread = threading.Thread(target=self.connect)
            thread.daemon = True
            thread.start()

    def process_incoming(self, data):
        if not self.online or self.detached:
            return
        self.rxb += len(data)
        if self.parent_interface:
            self.parent_interface.rxb += len(data)
        self.owner.inbound(data, self)

    def process_outgoing(self, data):
        if not self.online or self.detached:
            return
        try:
            if self.server_socket:  # Server-side mode
                self.server_socket.sendto(data, self.remote_address)
            else:  # Client-side mode
                self.udp_socket.sendto(data, (self.target_host, self.target_port))
            self.txb += len(data)
            if self.parent_interface:
                self.parent_interface.txb += len(data)
        except Exception as e:
            RNS.log(f"{self} transmit error: {e}", RNS.LOG_ERROR)

    def connect(self):
        if self.detached:
            return
        try:
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp_socket.bind(('0.0.0.0', 0))
            self.online = True
            threading.Thread(target=self.read_loop, daemon=True).start()
        except Exception as e:
            RNS.log(f"{self} connection failed: {e}", RNS.LOG_ERROR)
            time.sleep(self.RECONNECT_DELAY_SECONDS)
            self.connect()

    def read_loop(self):
        try:
            while True:
                data, addr = self.udp_socket.recvfrom(262144)
                self.process_incoming(data)
        except Exception as e:
            RNS.log(f"{self} read error: {e}", RNS.LOG_ERROR)
        finally:
            self.online = False

    def detach(self):
        self.online = False
        if self.udp_socket:
            self.udp_socket.close()
        self.detached = True

interface_class = WebsocketClientInterface