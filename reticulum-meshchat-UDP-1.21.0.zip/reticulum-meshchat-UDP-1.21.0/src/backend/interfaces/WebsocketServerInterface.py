import threading
import time
import socket

import RNS
from RNS.Interfaces.Interface import Interface

from src.backend.interfaces.WebsocketClientInterface import WebsocketClientInterface


class WebsocketServerInterface(Interface):

    DEFAULT_IFAC_SIZE = 16
    RESTART_DELAY_SECONDS = 5

    def __str__(self):
        return f"UdpServerInterface[{self.name}/{self.listen_ip}:{self.listen_port}]"

    def __init__(self, owner, configuration):
        super().__init__()
        self.owner = owner
        self.IN = True
        self.OUT = False
        self.HW_MTU = 262144  # 256KiB
        self.bitrate = 1_000_000_000
        self.mode = RNS.Interfaces.Interface.Interface.MODE_FULL

        self.udp_socket = None
        self.spawned_interfaces = {}  # Maps (ip, port) to interface

        ifconf = Interface.get_config_obj(configuration)
        self.name = ifconf.get("name")
        self.listen_ip = ifconf.get("listen_ip")
        self.listen_port = int(ifconf.get("listen_port"))

        thread = threading.Thread(target=self.serve)
        thread.daemon = True
        thread.start()

    @property
    def clients(self):
        return len(self.spawned_interfaces)

    def serve(self):
        try:
            RNS.log(f"Starting UDP server for {self}...", RNS.LOG_DEBUG)
            self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp_socket.bind((self.listen_ip, self.listen_port))
            self.online = True

            while True:
                data, addr = self.udp_socket.recvfrom(self.HW_MTU)
                if addr not in self.spawned_interfaces:
                    spawned = WebsocketClientInterface(
                        self.owner,
                        {
                            "name": f"Client on {self.name}",
                            "target_host": addr[0],
                            "target_port": addr[1],
                        },
                        server_socket=self.udp_socket,
                        remote_address=addr
                    )
                    spawned.IN = self.IN
                    spawned.OUT = self.OUT
                    spawned.HW_MTU = self.HW_MTU
                    spawned.bitrate = self.bitrate
                    spawned.mode = self.mode
                    spawned.parent_interface = self
                    spawned.online = True
                    self.spawned_interfaces[addr] = spawned
                    RNS.Transport.interfaces.append(spawned)
                self.spawned_interfaces[addr].process_incoming(data)
        except Exception as e:
            RNS.log(f"{self} failed: {e}", RNS.LOG_ERROR)
            self.online = False
            time.sleep(self.RESTART_DELAY_SECONDS)
            self.serve()

    def detach(self):
        self.online = False
        if self.udp_socket:
            self.udp_socket.close()
        for addr, iface in self.spawned_interfaces.items():
            iface.detach()
        self.spawned_interfaces.clear()
        self.detached = True

interface_class = WebsocketServerInterface