self.addEventListener('fetch',function() {
    // this is required to meet the requirements for an installable pwa
    // it allows the browser to ask the user if they want to install to their homescreen
});
