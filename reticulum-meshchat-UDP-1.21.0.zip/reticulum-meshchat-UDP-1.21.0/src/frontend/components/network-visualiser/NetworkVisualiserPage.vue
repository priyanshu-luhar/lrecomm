<template>
    <NetworkVisualiser/>
</template>

<script>
import NetworkVisualiser from "./NetworkVisualiser.vue";

export default {
    name: 'NetworkVisualiserPage',
    components: {
        NetworkVisualiser,
    },
}
</script>
