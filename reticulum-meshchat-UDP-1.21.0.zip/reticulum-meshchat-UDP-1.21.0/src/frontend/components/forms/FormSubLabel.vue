<template>
    <div class="text-xs text-gray-600 dark:text-zinc-300">
        <slot/>
    </div>
</template>
<script>
export default {
    name: 'FormSubLabel',
}
</script>