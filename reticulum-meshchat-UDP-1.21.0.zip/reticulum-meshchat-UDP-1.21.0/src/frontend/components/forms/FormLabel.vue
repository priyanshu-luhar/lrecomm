<template>
    <label class="block text-sm font-medium text-gray-900 dark:text-zinc-100">
        <slot/>
    </label>
</template>
<script>
export default {
    name: 'FormLabel',
}
</script>